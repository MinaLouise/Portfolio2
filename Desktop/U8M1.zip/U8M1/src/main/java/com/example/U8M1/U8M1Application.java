package com.example.U8M1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class U8M1Application {

	public static void main(String[] args) {
		SpringApplication.run(U8M1Application.class, args);
	}

}
