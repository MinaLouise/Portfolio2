package com.example.U8M1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class U8M1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
